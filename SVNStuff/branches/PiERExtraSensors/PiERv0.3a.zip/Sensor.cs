using System;
using Microsoft.SPOT;

namespace PiEAPI
{
    public interface Sensor
    {

    }
}
